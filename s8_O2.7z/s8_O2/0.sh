#!/bin/bash

# 프로그램 실행 파일
EXECUTABLE="./test_arm_convolve_s8"

# cachegrind 결과 파일을 저장할 디렉토리
OUTPUT_DIR="."

# 실행 파일을 100번 실행하고 결과 파일 생성
for i in {1..100}; do
    OUTPUT_FILE="${OUTPUT_DIR}/O2_${i}"

    # valgrind를 백그라운드에서 실행하고 결과를 콘솔에 출력하면서 파일에 저장
    OUTPUT=$(valgrind --tool=cachegrind --cachegrind-out-file="${OUTPUT_FILE}" "${EXECUTABLE}" 2>&1 | grep "Runtime:" | awk '{print $2}')
    
    # 결과 출력
    echo "$i : $OUTPUT"

done

