#!/bin/bash

# 프로그램 실행 파일
EXECUTABLE="./test_arm_convolve_s8"

# cachegrind 결과 파일을 저장할 디렉토리
OUTPUT_DIR="."

COMMAND="valgrind --tool=cachegrind --cachegrind-out-file=${OUTPUT_FILE} ${EXECUTABLE} > /dev/null 2>&1 &"

# 실행 파일을 100번 실행하고 결과 파일 생성
for i in {1..100}; do
    OUTPUT_FILE="${OUTPUT_DIR}/O0_${i}"
    OUTPUT=$(valgrind --tool=cachegrind --cachegrind-out-file="${OUTPUT_FILE}" "${EXECUTABLE}" > /dev/null 2>&1 & | grep "Runtime:" | awk'{print $2}')
    echo "$OUTPUT"
done

